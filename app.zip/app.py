import pandas as pd
import ast
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import streamlit as st

# Load English movies
df_en = pd.read_csv("english_movies.csv")
df_en = df_en[df_en['original_language'] == 'en'][['title', 'genres', 'overview']].copy()

def parse_genre_tmdb(genre_str):
    try:
        genres = ast.literal_eval(genre_str)
        return " ".join([g['name'].lower() for g in genres])
    except:
        return ""

df_en['genre'] = df_en['genres'].apply(parse_genre_tmdb)
df_en = df_en.rename(columns={'overview': 'description'}).drop(columns=['genres'])
df_en['language'] = 'en'

# Load Telugu movies
df_te = pd.read_csv("telugu_movies_100.csv")
df_te = df_te[['title', 'genre', 'description']]
df_te['genre'] = df_te['genre'].str.lower()
df_te['description'] = df_te['description'].fillna("")
df_te['language'] = 'te'

# Combine datasets
df = pd.concat([df_en, df_te], ignore_index=True)
df['description'] = df['description'].fillna("")
df['genre'] = df['genre'].fillna("")
df['combined'] = df['genre'] + " " + df['description']
df['title_lower'] = df['title'].str.lower()

# TF-IDF vectorizer
vectorizer = TfidfVectorizer(stop_words='english')
tfidf_matrix = vectorizer.fit_transform(df['combined'])
cosine_sim = cosine_similarity(tfidf_matrix, tfidf_matrix)

# Recommendation by title
def get_recommendations_by_title(title, top_n=5):
    title = title.lower()
    if title not in df['title_lower'].values:
        return ["❌ Movie not found. Try another title."]
    idx = df[df['title_lower'] == title].index[0]
    input_lang = df.iloc[idx]['language']
    sim_scores = list(enumerate(cosine_sim[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)

    recommended = []
    for i in sim_scores:
        movie_title = df.iloc[i[0]]['title']
        movie_lang = df.iloc[i[0]]['language']
        if movie_title.lower() != title and 'part' not in movie_title.lower():
            if input_lang == 'te' and movie_lang == 'te':
                recommended.append(movie_title)
            elif input_lang == 'en':
                recommended.append(movie_title)
        if len(recommended) >= top_n:
            break
    return recommended

# Recommendation by genre
def get_recommendations_by_genre(genre, top_n=5):
    genre = genre.lower()
    matches = df[df['genre'].str.contains(genre, na=False)]
    if matches.empty:
        return ["❌ Genre not found. Try 'action', 'drama', 'romance', etc."]
    return matches['title'].drop_duplicates().sample(n=min(top_n, len(matches))).tolist()

# Streamlit UI
st.title("🎬 Movie Recommendation System (Telugu + English)")
user_input = st.text_input("🔍 Enter a movie title or genre:")

if user_input:
    if user_input.lower() in df['title_lower'].values:
        st.subheader("🎯 Recommended Movies Based on Title:")
        results = get_recommendations_by_title(user_input)
    else:
        st.subheader("🎯 Recommended Movies Based on Genre:")
        results = get_recommendations_by_genre(user_input)

    for r in results:
        st.write("→", r)

